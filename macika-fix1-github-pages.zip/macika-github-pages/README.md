# Macika AI Studio — GitHub Pages

Build ini berisi perbaikan navigasi **Coba Generator** agar menuju bagian **1. Pilih Produk**.

## Upload ke GitHub
1. Ekstrak ZIP ini.
2. Buka repository GitHub tujuan.
3. Upload `index.html`, `.nojekyll`, dan `README.md` ke direktori utama (root) repository.
4. Buka **Settings → Pages**.
5. Pada **Build and deployment**, pilih **Deploy from a branch**.
6. Pilih branch yang digunakan (misalnya `main`) dan folder `/(root)`, lalu klik **Save**.

Pastikan `index.html` berada langsung di root repository, bukan di dalam folder tambahan.
